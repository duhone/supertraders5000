// noorbitniobject.cpp: implementation of the noorbitniobject class.
//
//////////////////////////////////////////////////////////////////////

#include "noorbitniobject.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

noorbitniobject::noorbitniobject()
{

}

noorbitniobject::~noorbitniobject()
{

}

bool noorbitniobject::collision(float x,float y)
{

	return false;
}

float noorbitniobject::getgravity(float x,float y)
{

	return 0.0f;
}

void noorbitniobject::cull()
{

}

void noorbitniobject::draw()
{

}

void noorbitniobject::viewtransform(float xp,float yp)
{

}

void noorbitniobject::move()
{

}
